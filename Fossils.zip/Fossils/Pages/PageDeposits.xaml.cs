﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDeposits.xaml
    /// </summary>
    public partial class PageDeposits : Page
    {
        public PageDeposits()
        {
            InitializeComponent();
            DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
        }

        private void MenuAddDeposit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageDeposits(null));
        }

        private void MenuEditDeposit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageDeposits((Deposits)DtgSQLD.SelectedItem));
        }

        private void MenuDelDeposit_Click(object sender, RoutedEventArgs e)
        {
            var depositsForRemoving = DtgSQLD.SelectedItems.Cast<Deposits>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {depositsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MiningEntitiesDB.GetContext().Deposits.RemoveRange(depositsForRemoving);
                    MiningEntitiesDB.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLD.ItemsSource = MiningEntitiesDB.GetContext().Deposits.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionSales_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageSales());
        }

        private void BtnTransitionFossils_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageFossils());
        }
    }
}
