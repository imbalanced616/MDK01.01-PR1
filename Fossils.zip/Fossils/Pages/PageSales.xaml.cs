﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageSales.xaml
    /// </summary>
    public partial class PageSales : Page
    {
        public PageSales()
        {
            InitializeComponent();
            DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.ToList();
        }

        private void MenuAddSale_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSales(null));
        }

        private void MenuEditSale_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSales((Sales)DtgSQLS.SelectedItem));
        }

        private void MenuDelSale_Click(object sender, RoutedEventArgs e)
        {
            var salesForRemoving = DtgSQLS.SelectedItems.Cast<Sales>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {salesForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MiningEntitiesDB.GetContext().Sales.RemoveRange(salesForRemoving);
                    MiningEntitiesDB.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLS.ItemsSource = MiningEntitiesDB.GetContext().Sales.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionDeposits_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
        }

        private void BtnTransitionFossils_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageFossils());
        }
    }
}
