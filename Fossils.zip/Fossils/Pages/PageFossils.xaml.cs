﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageFossils.xaml
    /// </summary>
    public partial class PageFossils : Page
    {
        public PageFossils()
        {
            InitializeComponent();
            DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
        }

        private void MenuAddFossil_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageFossils(null));
        }

        private void MenuEditFossil_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageFossils((FossilsBD)DtgSQLF.SelectedItem));
        }

        private void MenuDelFossil_Click(object sender, RoutedEventArgs e)
        {
            var fossilsForRemoving = DtgSQLF.SelectedItems.Cast<FossilsBD>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {fossilsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MiningEntitiesDB.GetContext().FossilsBD.RemoveRange(fossilsForRemoving);
                    MiningEntitiesDB.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLF.ItemsSource = MiningEntitiesDB.GetContext().FossilsBD.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionSales_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageSales());
        }

        private void BtnTransitionDeposits_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
        }
    }
}
